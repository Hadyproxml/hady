# **App Name**: X-Ray Queue Manager

## Core Features:

- Patient List Display: Display a sequential list of patient names in the queue.
- Add New Patient: Add a new patient name to the end of the queue.
- Status Tracking: Visual indicator (Green/Red) for 'Waiting' and 'Completed' statuses.
- Queue Reordering: Drag and drop functionality to reorder patient priority.
- Remaining Cases Counter: Display the number of patients currently waiting.
- Persistent Data: Save and persist patient data even when the app is closed.

## Style Guidelines:

- Primary color: Soft blue (#A7D1F7) to create a calm and professional atmosphere.
- Background color: Light gray (#F0F4F8) to ensure high readability.
- Accent color: Green (#6ACCBC) for 'Waiting' status and red (#E57373) for 'Completed' status.
- Body and headline font: 'PT Sans', a modern, clean, sans-serif.
- Use simple, standard Android icons for add, drag, and status indicators.
- Clean and intuitive layout with a focus on list clarity and ease of use.
- Subtle transitions when updating patient statuses or reordering the queue.
// src/firebase/config.ts
import { FirebaseOptions } from 'firebase/app';

const firebaseConfigString = process.env.NEXT_PUBLIC_FIREBASE_CONFIG;

if (!firebaseConfigString) {
  throw new Error(
    'Firebase config is not set. Please add NEXT_PUBLIC_FIREBASE_CONFIG to your .env.local file.'
  );
}

const firebaseConfig: FirebaseOptions = JSON.parse(firebaseConfigString);

// Check if the config is valid
if (
  !firebaseConfig.apiKey ||
  !firebaseConfig.authDomain ||
  !firebaseConfig.projectId
) {
  throw new Error(
    'Firebase config is not valid. Please check your NEXT_PUBLIC_FIREBASE_CONFIG in .env.local.'
  );
}

export default firebaseConfig;

// src/firebase/firestore/use-doc.tsx
'use client';
import {
  DocumentReference,
  DocumentData,
  onSnapshot,
} from 'firebase/firestore';
import { useEffect, useState } from 'react';

// This hook is used to listen to a document in Firestore.
// It returns the data, loading state, and error state.
// It also automatically unsubscribes from the listener when the component unmounts.
export function useDoc<T extends DocumentData>(
  docRef: DocumentReference<T> | null,
  options: { listen?: boolean } = { listen: true }
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const { listen } = options;

  useEffect(() => {
    if (!docRef) {
      setLoading(false);
      return;
    }

    if (!listen) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsubscribe = onSnapshot(
      docRef,
      (doc) => {
        if (doc.exists()) {
          setData({ id: doc.id, ...doc.data() } as T);
        } else {
          setData(null);
        }
        setLoading(false);
      },
      (err) => {
        console.error('Listen to document error:', err);
        setError(err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [docRef, listen]);

  return { data, loading, error };
}

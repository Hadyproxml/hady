// src/firebase/firestore/use-collection.tsx
'use client';
import {
  Query,
  DocumentData,
  onSnapshot,
  QuerySnapshot,
} from 'firebase/firestore';
import { useEffect, useState, useMemo } from 'react';

// This hook is used to listen to a collection in Firestore.
// It returns the data, loading state, and error state.
// It also automatically unsubscribes from the listener when the component unmounts.
export function useCollection<T extends DocumentData>(
  query: Query<T> | null,
  options: { listen?: boolean } = { listen: true }
) {
  const [data, setData] = useState<T[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const { listen } = options;

  useEffect(() => {
    if (!query) {
      setLoading(false);
      return;
    }
    setLoading(true);

    const unsubscribe = onSnapshot(
      query,
      (snapshot: QuerySnapshot<T>) => {
        const result: T[] = [];
        snapshot.forEach((doc) => {
          result.push({ id: doc.id, ...doc.data() } as T);
        });
        setData(result);
        setLoading(false);
        setError(null);
      },
      (err: Error) => {
        console.error('Listen to collection error:', err);
        setError(err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [JSON.stringify(query), listen]);

  return { data, loading, error };
}

import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";

export function QueueSkeleton() {
  return (
    <div className="min-h-screen">
       <div className="py-6 px-4 text-center border-b">
         <Skeleton className="h-8 w-3/4 max-w-sm mx-auto" />
         <Skeleton className="h-6 w-1/2 max-w-xs mx-auto mt-2" />
       </div>
       <main className="p-4 mx-auto max-w-2xl space-y-4">
        <Card>
          <CardContent className="p-4 flex gap-2">
            <Skeleton className="h-10 flex-grow" />
            <Skeleton className="h-10 w-10" />
          </CardContent>
        </Card>

        <div className="space-y-3 pt-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="p-2 pr-3 flex items-center gap-4">
              <Skeleton className="h-6 w-6" />
              <Skeleton className="h-6 flex-grow" />
              <Skeleton className="h-8 w-8 rounded-full" />
            </Card>
          ))}
        </div>
       </main>
    </div>
  );
}

'use client';

import { useMemo, useCallback } from 'react';
import { useCollection, useFirestore } from '@/firebase';
import { collection, addDoc, doc, updateDoc, deleteDoc, writeBatch, serverTimestamp, query, orderBy, Timestamp } from 'firebase/firestore';

import type { Patient } from '@/app/types';
import { AddPatientForm } from '@/components/patient/add-patient-form';
import { PatientList } from '@/components/patient/patient-list';
import { QueueHeader } from '@/components/patient/queue-header';
import { QueueSkeleton } from '@/components/patient/queue-skeleton';
import { useToast } from '@/hooks/use-toast';

export function PatientQueue() {
  const firestore = useFirestore();
  const patientsCollection = useMemo(() => firestore ? collection(firestore, 'patients') : null, [firestore]);
  
  // This composite query requires an index. The index is defined in `backend.json`.
  const patientsQuery = useMemo(() => 
    patientsCollection 
      ? query(
          patientsCollection, 
          orderBy('status', 'desc'), // 'waiting' comes before 'completed'
          orderBy('order', 'asc'),      // For waiting patients
          orderBy('createdAt', 'desc')  // For completed patients
        ) 
      : null, 
  [patientsCollection]);

  const { data: patients, loading, error } = useCollection<Patient>(patientsQuery, { listen: true });

  const { toast } = useToast();

  const handleAddPatient = useCallback(async (name: string, examination: string) => {
    if (!firestore || !patients) return;

    try {
      const waitingPatients = patients.filter(p => p.status === 'waiting');
      const maxOrder = waitingPatients.length > 0 ? Math.max(...waitingPatients.map(p => p.order)) : -1;
      
      await addDoc(collection(firestore, 'patients'), {
        name,
        examination,
        status: 'waiting',
        order: maxOrder + 1,
        createdAt: serverTimestamp(),
      });

    } catch (e) {
      console.error("Error adding document: ", e);
      toast({
        variant: 'destructive',
        title: "خطأ",
        description: "لم يتمكن من إضافة المريض. الرجاء المحاولة مرة أخرى.",
      });
    }
  }, [firestore, patients, toast]);

  const handleToggleStatus = useCallback(async (id: string, currentStatus: 'waiting' | 'completed') => {
    if (!firestore || !patients) return;
    const patientRef = doc(firestore, 'patients', id);
    const newStatus = currentStatus === 'waiting' ? 'completed' : 'waiting';

    try {
        if (newStatus === 'waiting') {
            const waitingPatients = patients.filter(p => p.status === 'waiting' && p.id !== id);
            const maxOrder = waitingPatients.length > 0 ? Math.max(...waitingPatients.map(p => p.order)) : -1;
            await updateDoc(patientRef, { status: 'waiting', order: maxOrder + 1, createdAt: serverTimestamp() });
        } else {
            // When completing, set order to a high value so it sorts last for waiting patients.
            // createdAt is updated to mark completion time.
            await updateDoc(patientRef, { status: 'completed', order: 9999, createdAt: serverTimestamp() });
        }
    } catch (e) {
        console.error("Error updating status: ", e);
    }
  }, [firestore, patients]);
  
  const handleReorder = useCallback(async (draggedId: string, targetId: string) => {
    if (!firestore || !patients) return;

    const batch = writeBatch(firestore);
    const waitingPatients = [...patients].filter(p => p.status === 'waiting').sort((a,b) => a.order - b.order);

    const draggedIndex = waitingPatients.findIndex(p => p.id === draggedId);
    const targetIndex = waitingPatients.findIndex(p => p.id === targetId);

    if (draggedIndex === -1 || targetIndex === -1) return;

    // Reorder logic
    const [draggedItem] = waitingPatients.splice(draggedIndex, 1);
    waitingPatients.splice(targetIndex, 0, draggedItem);
    
    // Update order property in Firestore
    waitingPatients.forEach((patient, index) => {
        const patientRef = doc(firestore, 'patients', patient.id);
        if (patient.order !== index) {
          batch.update(patientRef, { order: index });
        }
    });
    
    try {
      await batch.commit();
    } catch (e) {
      console.error("Error reordering patients: ", e);
    }

  }, [firestore, patients]);

  const handleDeletePatient = useCallback(async (id: string) => {
    if (!firestore) return;
    try {
      await deleteDoc(doc(firestore, 'patients', id));
      toast({
        variant: 'destructive',
        title: "تم حذف المريض",
        description: "تمت إزالة المريض من الطابور بنجاح.",
      });
    } catch (e) {
      console.error("Error deleting document: ", e);
    }
  }, [firestore, toast]);

  const handleUpdatePatient = useCallback(async (id: string, newName: string, newExamination: string) => {
    if (!firestore) return;
    if (!newName.trim() || !newExamination.trim()) {
      toast({
        variant: 'destructive',
        title: "خطأ",
        description: "لا يمكن أن يكون اسم المريض أو الفحص فارغًا.",
      });
      return;
    }
    try {
      const patientRef = doc(firestore, 'patients', id);
      await updateDoc(patientRef, { name: newName.trim(), examination: newExamination.trim() });
      toast({
        title: "تم تحديث البيانات",
        description: "تم تغيير بيانات المريض بنجاح.",
      });
    } catch (e) {
      console.error("Error updating document: ", e);
    }
  }, [firestore, toast]);

  const handleClearAll = useCallback(async () => {
    if (!firestore || !patients) return;
    const batch = writeBatch(firestore);
    patients.forEach(patient => {
      const patientRef = doc(firestore, 'patients', patient.id);
      batch.delete(patientRef);
    });
    try {
      await batch.commit();
      toast({
        variant: 'destructive',
        title: 'تم حذف السجل',
        description: 'تم حذف جميع بيانات المرضى بنجاح.',
      });
    } catch (e) {
      console.error("Error clearing all patients: ", e);
    }
  }, [firestore, patients, toast]);


  const waitingCount = useMemo(() => {
    return patients ? patients.filter((p) => p.status === 'waiting').length : 0;
  }, [patients]);
  

  if (loading) {
    return <QueueSkeleton />;
  }

   if (error) {
    return <div className="text-center py-20 text-destructive">حدث خطأ أثناء تحميل البيانات. الرجاء تحديث الصفحة.</div>;
  }

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ WebkitTouchCallout: 'none' }}>
      <QueueHeader waitingCount={waitingCount} onClearAll={handleClearAll} />
      <main className="container mx-auto max-w-xl p-2 sm:p-4 space-y-4">
        <AddPatientForm onAddPatient={handleAddPatient} />
        <PatientList 
          patients={patients || []} 
          onToggleStatus={handleToggleStatus} 
          onDeletePatient={handleDeletePatient}
          onUpdatePatient={handleUpdatePatient}
          onReorder={handleReorder}
        />
      </main>
    </div>
  );
}

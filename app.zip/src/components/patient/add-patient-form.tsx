'use client';

import { useState, type FC, type FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus } from 'lucide-react';
import { Card, CardContent, CardFooter } from '../ui/card';

interface AddPatientFormProps {
  onAddPatient: (name: string, examination: string) => void;
}

export const AddPatientForm: FC<AddPatientFormProps> = ({ onAddPatient }) => {
  const [name, setName] = useState('');
  const [examination, setExamination] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (name.trim() && examination.trim() && !isAdding) {
      setIsAdding(true);
      onAddPatient(name.trim(), examination.trim());
      setName('');
      setExamination('');
      // The parent component will set isAdding to false after the operation.
      // For a better UX, we can also set it back after a small delay.
      setTimeout(() => setIsAdding(false), 1000);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="sticky top-2 z-10 p-1 bg-background/80 backdrop-blur-sm rounded-lg">
       <Card className="shadow-sm border">
        <CardContent className="p-3 space-y-2">
            <Input
              type="text"
              placeholder="اسم المريض..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              aria-label="اسم المريض الجديد"
              required
              className="text-lg h-12"
              disabled={isAdding}
            />
            <Input
              type="text"
              placeholder="اسم الفحص (مثال: أشعة سينية)"
              value={examination}
              onChange={(e) => setExamination(e.target.value)}
              aria-label="اسم الفحص"
              required
              className="text-lg h-12"
              disabled={isAdding}
            />
        </CardContent>
        <CardFooter className="p-3 pt-0">
            <Button type="submit" size="lg" aria-label="إضافة مريض" className="w-full h-12 text-lg" disabled={isAdding}>
              {isAdding ? 'جار الإضافة...' : (
                <>
                  <Plus className="ml-2 h-6 w-6" />
                  إضافة مريض للطابور
                </>
              )}
            </Button>
        </CardFooter>
      </Card>
    </form>
  );
};

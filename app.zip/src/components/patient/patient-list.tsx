'use client';

import type { FC } from 'react';
import { useState, useRef } from 'react';
import { Patient } from '@/app/types';
import {
  MoreVertical,
  Edit,
  Trash2,
  Stethoscope,
  User,
  Undo2,
  CheckCircle,
  GripVertical,
  Inbox,
} from 'lucide-react';
import {
  Card,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';


interface PatientListProps {
  patients: Patient[];
  onToggleStatus: (id: string, currentStatus: 'waiting' | 'completed') => void;
  onDeletePatient: (id: string) => void;
  onUpdatePatient: (id: string, newName: string, newExamination: string) => void;
  onReorder: (draggedId: string, targetId: string) => void;
}

export const PatientList: FC<PatientListProps> = ({ patients, onToggleStatus, onDeletePatient, onUpdatePatient, onReorder }) => {
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [newName, setNewName] = useState('');
  const [newExamination, setNewExamination] = useState('');
  
  const dragPatientId = useRef<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);


  const handleEditClick = (patient: Patient) => {
    setEditingPatient(patient);
    setNewName(patient.name);
    setNewExamination(patient.examination);
  };

  const handleSave = () => {
    if (editingPatient) {
      onUpdatePatient(editingPatient.id, newName, newExamination);
      setEditingPatient(null);
    }
  };

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, patient: Patient) => {
    if (patient.status !== 'waiting') {
        e.preventDefault();
        return;
    }
    e.dataTransfer.effectAllowed = 'move';
    // A slight delay to allow the browser to capture the drag image
    setTimeout(() => {
      e.currentTarget.style.opacity = '0.5';
      e.currentTarget.style.transform = 'scale(1.02)';
      e.currentTarget.classList.add('shadow-2xl');
    }, 0);
    dragPatientId.current = patient.id;
  }

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, targetId: string) => {
    e.preventDefault();
    const targetPatient = patients.find(p => p.id === targetId);
    if (targetPatient && targetPatient.status === 'waiting') {
      setDragOverId(targetId);
    }
  }
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault(); // This is necessary to allow dropping
  }
  
  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
    e.currentTarget.style.opacity = '1';
    e.currentTarget.style.transform = 'scale(1)';
    e.currentTarget.classList.remove('shadow-2xl');
    dragPatientId.current = null;
    setDragOverId(null);
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, dropTargetId: string) => {
    e.preventDefault();
    if (dragPatientId.current && dragPatientId.current !== dropTargetId) {
        onReorder(dragPatientId.current, dropTargetId);
    }
    setDragOverId(null);
  }

  const preventContextMenu = (e: React.MouseEvent | React.TouchEvent) => {
    // This helps prevent the default context menu on long press on touch devices
    e.preventDefault();
    e.stopPropagation();
  };


  if (patients.length === 0) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <Inbox className="mx-auto h-20 w-20" />
        <h3 className="mt-4 text-2xl font-semibold">الطابور فارغ</h3>
        <p className="mt-2 text-lg">أضف مريضًا جديدًا للبدء.</p>
      </div>
    );
  }
  
  const waitingPatients = patients.filter(p => p.status === 'waiting');

  return (
    <TooltipProvider>
      <div 
        className="space-y-3 pb-4"
        onDragOver={handleDragOver}
      >
        {patients.map((patient) => {
          const waitingIndex = waitingPatients.findIndex(p => p.id === patient.id);
          const isWaiting = patient.status === 'waiting';
          const isBeingDraggedOver = dragOverId === patient.id && dragPatientId.current !== patient.id;
          const isDragSource = dragPatientId.current === patient.id;

          return (
            <div key={patient.id} className="relative">
              <Card
                draggable={isWaiting}
                onDragStart={(e) => handleDragStart(e, patient)}
                onDragEnter={(e) => handleDragEnter(e, patient.id)}
                onDragLeave={() => setDragOverId(null)}
                onDragEnd={handleDragEnd}
                onDrop={(e) => handleDrop(e, patient.id)}
                onContextMenu={preventContextMenu}
                className={cn(
                  'flex items-center p-3 transition-all duration-200 shadow-md relative overflow-hidden group',
                  !isWaiting ? 'bg-secondary/60' : 'bg-card cursor-grab active:cursor-grabbing',
                  isDragSource && 'opacity-50',
                  'rounded-xl'
                )}
              >
                 {isBeingDraggedOver && <div className="absolute -top-1.5 left-0 right-0 h-1 bg-primary rounded-full animate-pulse" />}
                {isWaiting && (
                    <div className="flex items-center justify-center w-8 text-muted-foreground group-hover:text-foreground transition-colors touch-none cursor-grab" onPointerDown={(e)=>e.stopPropagation()}>
                        <GripVertical className="h-6 w-6"/>
                    </div>
                )}
                
                <Avatar className="h-12 w-12 mx-3">
                  <AvatarFallback className={cn(
                    'text-lg font-semibold',
                    !isWaiting ? 'bg-muted-foreground/30 text-card' : 'bg-primary/10 text-primary'
                  )}>
                    <User className="h-6 w-6" />
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-grow space-y-1">
                  <p
                    className={cn(
                      'font-bold text-xl',
                      !isWaiting && 'line-through text-muted-foreground'
                    )}
                  >
                    {patient.name}
                  </p>
                  <div className={cn('flex items-center gap-2 text-sm', !isWaiting ? 'text-muted-foreground' : 'text-primary')}>
                     <Stethoscope className="h-4 w-4" />
                     <p className="font-medium">{patient.examination}</p>
                  </div>

                  {isWaiting && (
                     <p className="text-sm font-medium text-muted-foreground">
                       {waitingIndex > 0 ? `أمامه ${waitingIndex} ${waitingIndex > 1 ? 'مرضى' : 'مريض'}` : 'الدور الحالي'}
                     </p>
                  )}
                </div>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => { e.stopPropagation(); onToggleStatus(patient.id, patient.status); }}
                      className={cn(
                        'rounded-full w-16 h-16 transition-all duration-300 transform active:scale-95 mx-2',
                        isWaiting ? 'hover:bg-green-100 dark:hover:bg-green-900/50' : 'hover:bg-amber-100 dark:hover:bg-amber-900/50'
                      )}
                      aria-label={isWaiting ? `تحديد ${patient.name} كمكتمل` : `إلغاء اكتمال ${patient.name}`}
                    >
                      {isWaiting ? (
                        <CheckCircle className="h-10 w-10 text-muted-foreground/30 transition-colors duration-300 group-hover:text-green-500" />
                      ) : (
                        <Undo2 className="h-9 w-9 text-amber-500" />
                      )}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>
                      {isWaiting ? 'تحديد كمكتمل' : 'إلغاء الإكمال'}
                    </p>
                  </TooltipContent>
                </Tooltip>
                
                <div onClick={(e) => e.stopPropagation()}>
                  <AlertDialog>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-10 w-10">
                          <MoreVertical className="h-5 w-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEditClick(patient)} disabled={!isWaiting}>
                          <Edit className="ml-2 h-4 w-4" />
                          <span>تعديل البيانات</span>
                        </DropdownMenuItem>
                        <AlertDialogTrigger asChild>
                          <DropdownMenuItem className="text-destructive focus:text-destructive">
                            <Trash2 className="ml-2 h-4 w-4" />
                            <span>حذف المريض</span>
                          </DropdownMenuItem>
                        </AlertDialogTrigger>
                      </DropdownMenuContent>
                    </DropdownMenu>

                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>هل أنت متأكد تمامًا؟</AlertDialogTitle>
                        <AlertDialogDescription>
                          هذا الإجراء سيقوم بحذف المريض "{patient.name}" بشكل نهائي من القائمة. لا يمكن التراجع عن هذا الإجراء.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>إلغاء</AlertDialogCancel>
                        <AlertDialogAction onClick={() => onDeletePatient(patient.id)} className="bg-destructive hover:bg-destructive/90">
                          نعم، قم بالحذف
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </Card>
            </div>
          )
        })}
      </div>

       <Dialog open={!!editingPatient} onOpenChange={() => setEditingPatient(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل بيانات المريض</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
             <div className="space-y-2">
                <Label htmlFor="patient-name">اسم المريض</Label>
                <Input
                  id="patient-name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="text-lg"
                  aria-label="اسم المريض الجديد"
                />
             </div>
             <div className="space-y-2">
                <Label htmlFor="examination-name">اسم الفحص</Label>
                <Input
                  id="examination-name"
                  value={newExamination}
                  onChange={(e) => setNewExamination(e.target.value)}
                  className="text-lg"
                  aria-label="اسم الفحص الجديد"
                />
              </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
               <Button variant="outline">إلغاء</Button>
            </DialogClose>
            <Button onClick={handleSave}>حفظ التغييرات</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
};

'use client';

import type { FC } from 'react';
import { ClipboardList, MoreVertical, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface QueueHeaderProps {
  waitingCount: number;
  onClearAll: () => void;
}

export const QueueHeader: FC<QueueHeaderProps> = ({ waitingCount, onClearAll }) => {
  return (
    <header className="sticky top-0 z-20 bg-background/90 backdrop-blur-sm border-b shadow-sm">
      <div className="container mx-auto max-w-xl px-4 py-4">
        <div className="flex items-center justify-between">
          <div className='flex items-center gap-3'>
            <div className="p-2 bg-primary/10 rounded-lg">
              <ClipboardList className="h-7 w-7 text-primary" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">
              طابور الأشعة
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">المنتظرون</p>
              <span className="font-bold text-2xl text-primary">
                {waitingCount}
              </span>
            </div>
            <AlertDialog>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-10 w-10">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <AlertDialogTrigger asChild>
                    <DropdownMenuItem className="text-destructive focus:text-destructive">
                      <Trash2 className="ml-2 h-4 w-4" />
                      <span>حذف السجل بالكامل</span>
                    </DropdownMenuItem>
                  </AlertDialogTrigger>
                </DropdownMenuContent>
              </DropdownMenu>

              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>هل أنت متأكد من حذف السجل بالكامل؟</AlertDialogTitle>
                  <AlertDialogDescription>
                    سيتم حذف جميع المرضى (المنتظرين والمكتملين) بشكل نهائي. لا يمكن التراجع عن هذا الإجراء.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>إلغاء</AlertDialogCancel>
                  <AlertDialogAction onClick={onClearAll} className="bg-destructive hover:bg-destructive/90">
                    نعم، قم بالحذف
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </header>
  );
};

import { PatientQueue } from '@/components/patient/patient-queue';

export default function Home() {
  return (
    <div className="bg-background">
      <main className="w-full max-w-xl mx-auto">
        <PatientQueue />
      </main>
    </div>
  );
}

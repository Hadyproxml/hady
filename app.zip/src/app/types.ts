export interface Patient {
  id: string;
  name: string;
  examination: string;
  status: 'waiting' | 'completed';
  order: number;
  createdAt: any; // Firestore Timestamp
}
